import React from 'react'
import Home from '../components/Home'

export const Dashboard = () => {
  return (
    <Home />
  )
}
