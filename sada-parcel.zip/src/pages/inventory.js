import React from 'react'

const inventory = () => {
  return (
    <div class="container">
        Sada Parcel
    </div>
  )
}

export default inventory;